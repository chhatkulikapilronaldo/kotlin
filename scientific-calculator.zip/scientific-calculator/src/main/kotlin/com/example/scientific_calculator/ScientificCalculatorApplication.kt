/*Student Name: Chhatkuli kapil
student_id: M24W7304  */

package com.example.scientific_calculator

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ScientificCalculatorApplication

fun main(args: Array<String>) {
	runApplication<ScientificCalculatorApplication>(*args)
}
