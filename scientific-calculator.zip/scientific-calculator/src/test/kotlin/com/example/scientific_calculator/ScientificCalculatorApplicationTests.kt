package com.example.scientific_calculator

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ScientificCalculatorApplicationTests {

	@Test
	fun contextLoads() {
	}

}
