package com.example.hybernetproject.service

import com.example.hybernetproject.model.Person
import com.example.hybernetproject.repository.PersonRepository
import org.springframework.stereotype.Service

@Service
class PersonService(private val personRepository: PersonRepository) {
    fun getAllPersons(): List<Person> = personRepository.findAll()
    fun savePerson(person: Person): Person = personRepository.save(person)
}