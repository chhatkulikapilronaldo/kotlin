package com.example.hybernetproject.controller

import com.example.hybernetproject.model.Person
import com.example.hybernetproject.service.PersonService
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/persons")
class PersonController(private val personService: PersonService) {

    @GetMapping
    fun getPersons(): List<Person> = personService.getAllPersons()

    @PostMapping
    fun addPerson(@RequestBody person: Person): Person = personService.savePerson(person)
}
