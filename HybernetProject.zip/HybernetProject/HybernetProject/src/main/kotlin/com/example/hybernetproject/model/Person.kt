package com.example.hybernetproject.model

import jakarta.persistence.*
import org.springframework.boot.autoconfigure.amqp.RabbitConnectionDetails.Address

@Entity
data class Person(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,

    val name: String = "",

    val age: Int = 0,

    val address: String ="",
    val contact: Int = 0
)