package com.example.soapostrequestsample

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SoapostrequestsampleApplicationTests {

    @Test
    fun contextLoads() {
    }

}
