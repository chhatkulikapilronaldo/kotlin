# Spring Security Log Errors Project

This project demonstrates Spring Boot Kotlin security with custom error handling, access denied messages, styled Thymeleaf pages, and logging.

- Custom login/logout pages
- Admin and user roles
- Logs with timestamps
