package com.example.rolebasedloginlogger

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RoleBasedLoginLoggerApplicationTests {

    @Test
    fun contextLoads() {
    }

}
