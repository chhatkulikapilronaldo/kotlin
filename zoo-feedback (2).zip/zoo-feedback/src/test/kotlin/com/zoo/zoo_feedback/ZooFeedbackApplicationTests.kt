package com.zoo.zoo_feedback

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ZooFeedbackApplicationTests {

	@Test
	fun contextLoads() {
	}

}
