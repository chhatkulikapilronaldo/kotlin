package com.zoo.zoo_feedback

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ZooFeedbackApplication

fun main(args: Array<String>) {
	runApplication<ZooFeedbackApplication>(*args)
}
