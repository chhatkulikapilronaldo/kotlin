package com.example.simplesoapservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SimpleSoapServiceApplicationTests {

    @Test
    fun contextLoads() {
    }

}
