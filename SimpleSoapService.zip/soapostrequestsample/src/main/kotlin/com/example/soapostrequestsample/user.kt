package com.example.soapostrequestsample



data class user(
    val id: Long,
    val name: String,
    val email: String
)