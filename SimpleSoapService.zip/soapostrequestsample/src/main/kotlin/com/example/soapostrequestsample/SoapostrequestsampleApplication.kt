package com.example.soapostrequestsample

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SoapostrequestsampleApplication

fun main(args: Array<String>) {
    runApplication<SoapostrequestsampleApplication>(*args)
}
